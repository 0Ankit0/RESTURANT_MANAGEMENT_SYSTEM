﻿namespace $safeprojectname$.Models.Users
{
    public class RoleModel
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string GUID { get; set; }
    }
}
